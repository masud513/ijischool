import 'package:eschool/app/app.dart';

///[V.1.6.0]
///

Future<void> main() async {
  await initializeApp();
}
