class Module {
  final String name;
  final int id;

  const Module({required this.id, required this.name});
}
