///
///[PLEASE DO NOT MODIFIED THIS MODULE IDS]
///

const int studentManagementModuleId = 1;
const int academicsManagementModuleId = 2;
const int sliderManagementModuleId = 3;
const int teacherManagementModuleId = 4;
const int sessionYearManagementId = 5;
const int holidayManagementModuleId = 6;
const int timetableManagementModuleId = 7;
const int attendanceManagementModuleId = 8;
const int examManagementModuleId = 9;
const int lessonManagementModuleId = 10;
const int assignmentManagementModuleId = 11;
const int announcementManagementModuleId = 12;
const int staffManagementModuleId = 13;
const int expenseManagementModuleId = 14;
const int staffLeaveManagementModuleId = 15;
const int feesManagementModuleId = 16;
const int galleryManagementModuleId = 17;

//
const int chatModuleId = 20;
const int defaultModuleId = -1;
const String moduleIdJoiner = "#";
